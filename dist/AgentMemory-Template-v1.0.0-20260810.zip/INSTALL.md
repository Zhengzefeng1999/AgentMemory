# AgentMemory 模板包安装指南（部署者用）

本包是 AgentMemory 记忆银行的**架构模板**，不含任何个人记忆。
按以下步骤部署到你的机器（Windows / macOS / Linux 均可，需 Python 3.8+）。

## 1. 解压并放置

```bash
# 建议解压到非系统盘，例如 Windows: <盘符\AgentMemory
# 或 Linux: ~/AgentMemory
unzip AgentMemory-Template-v1.0.0.zip -d <盘符>:/AgentMemory
```

## 2. 配置路径（pi 用户可选）

如果你用 pi / Claude Code 等 agent，把 `SKILL.md.template` 复制为
agent 的 skill 目录下的 `memory-bank/SKILL.md`，并把文件里的
`<MEMORY_ROOT>` 替换为你的实际路径（如 `<盘符>:/AgentMemory`）。

## 3. 配置 LLM key（可选，仅每周提炼用）

```bash
cp .env.example .env
# 编辑 .env，填入 OpenAI 兼容的 LLM key（如 DeepSeek）：
#   DEEPSEEK_API_KEY=sk-xxx
# 检索不需要 key，只有 consolidate.py --mode llm 提炼时才用。
```

## 4. 初始化

```bash
python scripts/build_index.py        # 重建索引
python scripts/memory_tool.py health # 验证（应显示示例条目）
python tests/test_memory_tool.py     # 自测（6 项）
python tests/test_consolidate.py     # consolidate 窗口过滤回归测试（7 项）
git init && git add -A && git commit -m "init"   # 建立版本管理
```

## 5. 开始使用

```bash
python scripts/memory_tool.py add --title "第一条记忆" --tags "a,b" --category knowledge --body "内容"
python scripts/memory_tool.py search "关键词"
python scripts/memory_tool.py list --category knowledge
```

## 6. 日常运维

- 每周整理：`python scripts/consolidate.py --mode auto`（规则，零成本）
- 或带提炼：`python scripts/consolidate.py --mode llm`（用 .env 的 key）
- 敏感记忆：`add --secret`（摘要隐藏、不发给 LLM、get 需 --force）
- 安全：`.env` 已被 gitignore 排除 + pre-commit 钩子防 key 误提交（钩子随 git init 后自动生效；如需重新安装，把 `.git/hooks` 从模板的 `hooks/pre-commit` 复制）

## 文件说明

| 文件 | 说明 |
|------|------|
| `scripts/memory_tool.py` | 核心工具：add/search/get/update/archive/list/health |
| `scripts/build_index.py` | 重建 SQLite 索引（文件被外部编辑后跑） |
| `scripts/consolidate.py` | 整理：合并重复/淘汰过期/提炼 skill 候选 |
| `config.json` | 检索阈值、三档模式、LLM 配置 |
| `bank/` | 记忆库骨架（含 _SAMPLE_ 示例条目，可删） |
| `tests/` | 自测脚本 |

## 架构说明

- 纯 Python 标准库，零第三方依赖
- 脚本用自身位置推导根目录，**任何路径可部署**
- 检索本地 SQLite FTS，零 LLM token；记忆按需展开
- 三条底线：失败驱动检索 / 摘要导航 / 冲突优先
