# Skill 候选清单（CANDIDATES）

> 由 consolidate.py 从 patterns.md 提炼，或人工登记。
> 满 5 条时提醒用户审核，走 skill_manage 升级流程。

| # | 模式 | 出现次数 | 建议 skill | 状态 |
|---|------|---------|-----------|------|
